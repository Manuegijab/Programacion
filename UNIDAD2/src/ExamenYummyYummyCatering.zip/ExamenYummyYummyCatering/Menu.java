package ExamenYummyYummyCatering;

public class Menu {

}
