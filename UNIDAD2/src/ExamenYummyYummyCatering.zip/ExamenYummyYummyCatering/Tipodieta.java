package ExamenYummyYummyCatering;

public enum Tipodieta {

}
