package ExamenYummyYummyCatering;

public class Cliente {

}
