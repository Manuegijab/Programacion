package Modelo;

public interface IPago {
	  boolean validarMetodoPago();
	    boolean realizarPago();
	
}
