package RPG;

public class Mago extends Personaje {

	public Mago(String nombre, int nivel, int hp) {
		super(nombre, nivel, hp);
		// TODO Auto-generated constructor stub
	}
	protected boolean esatacado(Personaje atacante) {
	
	
			return false;
			
	
		
		
	}
}
