package ExamenYummyYummyCatering;

public enum Tipodieta {
VEGETARIANO,VEGANO,SIN_GLUTEN,SIN_LACTOSA;
}
