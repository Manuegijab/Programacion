package Simulacro;

import java.util.Random;
import java.util.Scanner;
public class Juegodados {
public static void main(String[] args) {
//primero se hará la función imprimemenu, la funcion apostar pedirá el numero sobre el que apuesta y la cantidad apostada y devolverá la suma



}

int imprimemenu() {
	Juegodados f=new Juegodados();

	int opcion=0;
	int numeroapuesta;
	int dineroapuesta;
	int sumadados;
	int dineroganancias=0;
	int numerovecesjugado=0;
	System.out.println("APOSTAR 1");
	System.out.println("MOSTRAR HISTORIAL 2");
	System.out.println("RETIRARSE 3 ");
	while(opcion<3) {
		switch(opcion) {
		case 1:{
			 numeroapuesta= f.preguntarapuesta();
			 dineroapuesta= f.dineroapuesta();
			 sumadados=f.lanzardadoysuma();			
			dineroganancias= dineroganancias + f.gestionarganancias(numeroapuesta,dineroapuesta,sumadados);
			numerovecesjugado= numerovecesjugado+1;
		}
		case 2: {
			
		}
		}
	}
		
	
}
int preguntarapuesta() {
	Scanner sc= new Scanner(System.in);
	System.out.println("Dime tu apuesta:");
	int numeroapuesta=sc.nextInt();
	return numeroapuesta;
}
int dineroapuesta() {
	Scanner sc= new Scanner(System.in);
	System.out.println("Cuanto dinero quieres apostar?");
	int cantidadapostada=sc.nextInt();
	return cantidadapostada;
	
}
int gestionarganancias(int numeroapuesta, int dineroapuesta, int sumadados) {
	int dineroganancia=0;
	
	if (numeroapuesta==sumadados) {
		dineroganancia=dineroganancia+dineroapuesta;
	}
	else {
		dineroganancia=dineroganancia-dineroapuesta;
	}
	return dineroganancia;
}

int lanzardadoysuma() {
	Random randomnumber=new Random();
	int dado1= randomnumber.nextInt();
	int dado2= randomnumber.nextInt();
	int sumadados=dado1+dado2;
	return sumadados;
}
String[] 




}
