package Funciones;

public class prueba {
	public static void main(String[] args) {

		prueba julian = new prueba();
		
		String[] tablanombres = julian.generanombres();
		
		System.out.println(tablanombres);

		for (int i = 0; i < tablanombres.length; i++) {
			System.out.println(tablanombres[i]);
		}
	}

	String[] generanombres() 
	{
	
	String [] nombres= new String [5];
	
	
	
	
	return nombres;
	}
}