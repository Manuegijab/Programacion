package Funciones;

public class grinch {
public static void main(String[] args) {

	grinch pedro= new grinch();
	String[] todoslosficheros= { "4085852hackGrinch_medidas_chimenea.pdf", "19hackGrinch_lista_regalos.docx", "72143hackGrinch_plan_de_rescate.txt", "5hackGrinch_inventario_juguetes.xlsx", "11hackGrinch_esquema_cueva.ppt.hack", "83534685hackGrinch_diario_personal.log", "92220hackGrinch_cartas_niños.csv", "2879707hackGrinch_manual_de_travesuras.pdf", "3000123hackGrinch_lista_enemigos.doc", "6000326hackGrinch_resumen_robos.txt" };
}
	String []quitahackeo(String todoslosficheros){
		
		
		return ficheros;
		
	}
}