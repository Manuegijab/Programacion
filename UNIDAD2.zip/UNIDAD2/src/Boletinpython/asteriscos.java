package Boletinpython;

public class asteriscos {
public static void main(String[] args) {
	int i;
	String cadena="";
	for ( i = 1; i<=5 ; i++) {
	cadena= cadena+"*";
	System.out.println(cadena);
	
}
}
}
