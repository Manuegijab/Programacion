package Boletin1;

public class Ejercicio1 {

	public static void main(String[] args) {
		int x=144;
		int y=999;
		System.out.println(x+y);
		System.out.println(x-y);
		System.out.println(x*y);
		System.out.println(x/y);

	}

}
