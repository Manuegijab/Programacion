package Pruebas;
import java.util.Scanner;
public class Prueba1 {
public static void main(String[] args) {
	