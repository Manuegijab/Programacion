package Pruebas;

public class Char {
public static void main(String[] args) {
	Character c='a';
	String cadena="Hola";
	c=cadena.charAt(2);
	System.out.println(c);
	
}
}
