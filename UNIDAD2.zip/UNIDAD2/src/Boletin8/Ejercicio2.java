package Boletin8;

public class Ejercicio2 {

}
